% ----------------------------------------------------------
% Klee-Minty
  function [a,b,c,rel,xmin,xmax] = fkm_pi_splx_norm(n,ncode,kvalb)
% Klee-Minty Problem (1972)
% n = Dimens�o  do  espa�o  ;
% Construction of the optimization problem normalizado.
% ncode = 1; Algoritmo de pontos interiores.
% ncode = 2; Revised Simplex Method. Constru��o do pb com as vari�veis slacks. 
% kvalb = Define o vetor b (0 < kvalb  < 1/2);
% =======================================================
% *************
% The problem
% maximizar  f(x) = C'*x
% subject to
%            A*x <= B
%            Xmin < X < Xmax.
% A   -> Matriz de restricoes.
% B   -> Vetor do sistema.
% *************
% Example para dimens�o n = 3:
% maximize 0*x1 + 0*x2 + x3
% subj. to
%          k*x1  - x2     <= 0
%          k*x1  + x2     <= 1

%          k*x2  - x3     <= 0
%          k*x2  + x3     <= 1
%              0 < kvalb  < 1/2
%              x1, x2, x3 >= 0
% *************
% =======================================================
  a = [];
  xmin(1,1) = 0.0;
  xmax(1,1) = 1.0;
  for i1=1:n-1
    % Determina��o de C
      c(i1,1)= 0;

    % Determina��o de A
      a(i1,i1)  = kvalb;
      a(i1,i1+1)= -1.0;
      
      a(i1+n-1,i1)  = kvalb;
      a(i1+n-1,i1+1)= 1.0;

    % Determina��o de b
      b(i1,1)= 0;
      b(i1+n-1,1)= 1;
  
    % REL -> Relacoes de desigualdade: -1 = "Ax <= B".
      rel(i1,1)    = -1;
      rel(i1+n-1,1)= -1;

    % Limits of X. Xmax and Xmin.
      xmin(i1+1,1) = kvalb*xmax(i1,1);
      xmax(i1+1,1) = 1.0 - xmin(i1+1,1);
  end
  c(n,1) = 1;
% ---------------------------  
  if ncode == 1
   % Determina��o de A
     a(2*n-2+1,1)  = -1;
     b(2*n-2+1,1)  =  0;
     rel(2*n-2+1,1)= -1;
     
     a(2*n-2+2,1)  =  1;
     b(2*n-2+2,1)  =  1;
     rel(2*n-2+2,1)= -1;
  end
  if ncode == 2 
   % Determina��o de C
     c = [c; zeros(2*n-2,1)];
  
   % Determina��o de A : acr�scimo das vari�veis slacks
     for i =1:(2*n-2)
         a(i,n+i) = 1;
     end
  end