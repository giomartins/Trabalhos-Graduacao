% ===============================================================
  function [x_tikhonov] = reg_tikhonov(A,b)
% TIKHONOV Tikhonov regularization.
% Computes the Tikhonov regularized solution x_tikhonov. If the SVD
% is used, i.e. if U, s, and V are specified, then standard-form
% regularization is applied:
%    min { || A x - b ||^2 + lambda^2 || x ||^2 }.
% Per Christian Hansen, IMM, 12/23/97.
% Reference: A. N. Tikhonov & V. Y. Arsenin, "Solutions of
% Ill-Posed Problems", Wiley, 1977.

% Initialization.
% *********************
% CSVD Compact singular value decomposition.
% Computes the compact form of the SVD of A:
%    A = U*diag(s)*V',
% where
%    U  is  m-by-min(m,n)
%    s  is  min(m,n)-by-1
%    V  is  n-by-min(m,n).
% SVD Singular value decomposition. [U,S,V] = SVD(A) produces a diagonal
% matrix S, of the same dimension as A and with nonnegative diagonal elements in
% decreasing order, and unitary matrices U and V so that A = U*S*V'.
% Per Christian Hansen, IMM, 06/22/93.
  V = [];
  U = [];
  s = [];
  x_tikhonov = [];
% ******************* modif 15/10/2007 *******************
  [m,n] = size(A);
  na = sqrt(sum(A.*A,2));
  A = A./repmat(na,1,n);
  b = b./na;
% ******************* modif 15/10/2007 *******************
  if m >= n
     [U,s,V] = svd(full(A),0);
  else
     [V,s,U] = svd(full(A)',0);
  end
  s = diag(s);
% *********************
  lambda = eps;
  n = size(V,1);
  p = length(s);
  zeta = s(:,1).*(U(:,1:p)'*b);
  x_tikhonov(:,1) = V(:,1:p)*(zeta./(s.^2 + lambda^2));
% ===============================================================