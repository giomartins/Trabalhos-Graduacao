% Este arquivo usa a fun��o findintp() para encontrar o ponto interior no espa�o de solu��o
%
% Ap�s o c�lculo do ponto interior, utilizamos o algoritmo de pontos interiores para convergir para a solu��o do problema

% ------------------------------------------------------------
% Specified value considered zero.
  EPSLON0 = 1.0e-08;
% Specified tolerance such that a calculated DELTAX = X - XOLD
% is considered zero if abs(max(DELTAX)) < EPSLON1 .
  EPSLON1 = 5.0e-04;
% ------------------------------------------------------------

% ------------------------------------
% Specified value considered infinite.
  INFMAX = 1.0e06;
% ------------------------------------

% ----------------------------------------------------------
% Define KALPHA
% KALPHA = input('fator KALPHA :  0 < KALPHA < 1 = ');
  KALPHA = 0.25;
% ----------------------------------------------------------

% ----------------------------------------------------------
% Define the number of iterations
% MAXITER = input('M�ximo n�mero de itera��es permitido = ');
  MAXITER = 100;
% ----------------------------------------------------------

% -----------------------------------------
% First call to the problem.
% Construction of the optimization problem.
%  [N,M,C,A,B,XMIN,XMAX,X0 ] = fhillie;
% load dados;
% -----------------------------------------

% ---------
  ITER =1;
  FLAG1=0; 
% ---------
 
  

% Restaura a tela para os seus valores default - - - - - - - - - - - - - - - - - - - - 

set(htxtResultX1,'Visible','off');
set(htxtResultX2,'Visible','off');

delete(get(hMainWin,'CurrentAxes'));

plot(v(:,1),v(:,2),'y-.');hold on;

set(get(hMainWin,'CurrentAxes'),'visible','off');
plot(v(:,1),v(:,2),'y-.');
axis([min(v(:,1))-1 max(v(:,1))+1 min(v(:,2))-1 max(v(:,2))+1 ]);

plot(min(v(:,1)),max(v(:,2)),'.'); 
hline = quiver(min(v(:,1)),max(v(:,2)),direcao(1),direcao(2),0);


% Tela restaurada - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

% C�lculo do ponto interior

[X0,A1,b1,g] = findintp(A,B,REL);

% - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -   
% Uso do algoritmo de pontos interiores para c�lculo da solu��o

FLAG_X0 = 1;

hplotContorno = plot(v(:,1),v(:,2),'b','LineWidth',5,'visible','on');

plot(X0(1),X0(2),'wo');

% Stockage the initial trial solution.
  X = X0;
  EVOLX = [X0];

% Evaluate objectif function.
  FOBJ = C'*X0;
  EVOLFOBJ = [FOBJ];

otimiz;
