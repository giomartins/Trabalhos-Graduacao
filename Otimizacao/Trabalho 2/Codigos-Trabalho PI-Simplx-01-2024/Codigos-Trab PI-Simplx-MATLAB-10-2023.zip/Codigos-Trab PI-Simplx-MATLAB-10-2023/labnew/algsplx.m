  function [X] = algsplx(A,B,C)
% Implementa��o do algoritmo Simplex
%               Max C^T.X
% sujeito a:    A.X <= B
% A fun��o retorna os valores ideais para X (vetor)
%
% Este algoritmo j� considera que a solu��o ocorre para X >=0
% Dessa forma n�o � necess�rio acrescentar tais par�metros �s matrizes A e B
%
% Como este programa trata-se de um exerc�cio n�o h� entrada de vari�veis (matrizes: A, B, C)
%  sendo estas definidas no pr�prio programa

% A = [1 0; 0 1; 3 2];
% B = [4; 6; 18]';
% C = [3; 5]';

% obtem o n�mero das vari�veis slack
  [n_slck, n_var] = size(A);

% Cria��o dos elementos da tabela
  Coeff_BV = 0*(1:n_slck)';
  BV = (n_var+1:n_var+n_slck)';
  Value_BV = B;
  AA = [A eye(n_slck)];
  CC = [C' zeros(1,n_slck)];
  
% --------------------------
% Loop para m�todo simplex.
  condicao = 1;
  cont = 1;
  while (condicao) & (cont~=100),  
      % inicia o algoritmo Simplex
        v = (Coeff_BV' * AA) - CC;
  
      % Se n�o houver elemento negativo, a solu��o foi encontrada  
        if (~sum(v<0))
           condicao = 0;
           break;
        end
  
      % obt�m o �ndice da menor componente de 'v'
        [Minimo, Indice] = min(v);
      % A vari�vel associada a esse valor � a nova BV
  
      % Calcular os quociente    
      % Verifica se n�o haver� divis�o por zero
        for aux = 1:n_slck
            if (AA(aux,Indice)==0)
               AA(aux,Indice) = 1e-9; % Atribui um valor muito pequeno, pr�ximo de zero
            end
        end
        quociente = Value_BV./AA(:,Indice); 
 
      % Elimina os valores negativo da matriz dos quocientes
      % subtituindo o valor m�ximo do vetor quociente em seu lugar
        quociente = quociente.*(quociente > 0) + max(quociente).*(quociente < 0);
 
      % Determinar o menor valor n�o-negativo
        [Minimo, IndPvt] = min(quociente);

      % Determinar o Elemento PIVOT
        PIVOT = AA(IndPvt,Indice);

      % Substitui a vari�vel slack pela vari�vel referente ao PIVOT 
        Coeff_BV(IndPvt) = CC(Indice);
 
      % Define uma nova vari�vel b�sica (BV - Basic Variable)
        BV(IndPvt) = Indice;
 
      % Executa uma opera��o na matriz AA de tal modo que na coluna da nova vari�vel slack,
      % todos os elementos sejam nulos exceto pelo elemento PIVOT que dever� ser unit�rio
        for aux = 1:n_slck
           if (aux ~= IndPvt)&(AA(aux,Indice)~=0)
              coef = -AA(aux,Indice)/PIVOT;
              AA(aux,:) = coef*AA(IndPvt,:) + AA(aux,:);
              Value_BV(aux) = coef*Value_BV(IndPvt) + Value_BV(aux);
           end
        end
        AA(IndPvt,:) = AA(IndPvt,:)/PIVOT;
        Value_BV(IndPvt) = Value_BV(IndPvt)/PIVOT;
        
      % Define o novo valor do contador de itera��es.
        cont =  cont + 1;

      % Exibe a solu��o encontrada nessa etapa
        solucao = 0*1:n_var;
        solucao(BV) = Value_BV;
        Coeff_BV'*Value_BV;
  end  % Fim do while.
     
% Observa��o: Neste problema n�o foi efetuada a parada por n�mero de itera��es,
% j� que o exerc�cio implementado normalmente converge.
% Uma das d�vidas neste problema consiste na implementa��o de pontos iniciais 
% para a execu��o do algoritmo. Inicialmente n�o � poss�vel implementar tal proposta.
% Neste problema o pr�prio algoritmo assume que os pontos iniciais s�o nulos

