%
% Loop dp arquivo de Demonstra��o do m�todo de
% Pontos Interiores.
%

    % Step I.

	     % Calculate the slack ( how far point is from each
	     % constraint).
               Vk = B - A*X;

	     % Let D be the corresponding diagonal matrix.
               Dk = eye(M);
               for I=1:M
	           if abs(Vk(I)) > EPSLON0
                      Dk(I,I) = 1/Vk(I);
   		   else
                      Dk(I,I) = INFMAX;
	    	   end;
               end;

      % Step II.
             % Calculate the projection of the current guess onto 
	     % the boundary of the sphere.
  	     % Solve the system of equations for dk
             % Gaussian elimination.
	       dk = (A'*Dk*Dk*A)\C;

	     % Scale the projected direction.
  	       dv = -A*dk;

      % Step III.
             % Identify the negative component. 
               for I=1:M
		   if dv(I) > -EPSLON0
                      Vaux(I) = -INFMAX;
		   else
                      Vaux(I) = Vk(I)/dv(I);
		   end;
               end;
 	       Valpha = max(Vaux);

	     % ----------------------------------------------------
	     % The current coordenates move from the current trial
	     % solution X to the next solution. The value of ALPHA
             % is chosen 0 < ALPHA < 1.
             % ----------------------------------------
	       AA = 1.5;
               BB = 1.0;
 	     % ALPHA defined :  0 < ALPHA < 1).
             % ALPHA(ITER) = 0.5;
             % ALPHA(ITER) = KALPHA*(1 - exp(-ITER*AA/(BB*N)));
             % ALPHA(ITER) = 1 - 1/(1+exp(ITER/2));

	       ALPHA(ITER) = ALPHA_GUI;

  	       X = X - ALPHA(ITER)*Valpha*dk;
             % ----------------------------------------

	     plot(X(1),X(2),'wo');
	     plot(EVOLX(1,:),EVOLX(2,:),'g');
	     drawnow;

      % Step IV.
     	      % Calculate X = D*XR as the trial solution for the next
	      % iteration (STEP I). IF this solution is virtually
	      % unchanged from the preceding one, then the algorithm
	      % has virtually converged to an optimal solution,
	      % so STOP.

              % Limits to X verified.
                for J = 1 : N
                    if X(J) < XMIN(J)
		       X(J) = XMIN(J);
		    end;
                    if X(J) > XMAX(J)
		       X(J) = XMAX(J);
		    end;
		end;

	      % Calculate DELTAX.
                if ITER ~= 1
                   DELTAX = X  - XOLD;

	      	 % If the solution X is EPSLON unchanged from the the
		 % preceding one, then the algorithm has an optimal
		 % solution.
	           if max(abs(DELTAX)) < EPSLON1
                      XOLD = X;
		      FLAG1 = 1;
		      FLAG_X0 = 0;

 	            %  disp('    '),
  		    %  disp('------------------------------------------'); 
  		    %  disp(' The algorithm has an optimal solution X.'),
                    %         X
  		    %  disp('------------------------------------------');
  		    %  disp('    '),

		   end;

	         % Evaluate objectif function.
                   FOBJ = C'*X; 
                   EVOLFOBJ = [EVOLFOBJ FOBJ];

	         % Calculate the candidate primal solution.
		   yk = Dk*Dk*dv;
		   if abs(FOBJ) > EPSLON1
		      Erro = abs((-B'*yk-FOBJ)/FOBJ);
		   else
		      Erro = abs(-B'*yk-FOBJ);
		   end;
	           if Erro < EPSLON1
		      FLAG1 = 1;
		      FLAG_X0 = 0;

 		      %disp('------------------------------------------'); 
  		      %disp(' The algorithm has an optimal solution X.'),
  		      %disp('------------------------------------------');
  		      %disp('    '),

		   end;

                end;

	      % Storage EVOLX.
		EVOLX = [EVOLX X];

	      % Storage XOLD as X.
                XOLD = X;

	      % Evaluate the number of iterations.
	        if ITER >= MAXITER
		   FLAG1 = 1;
		   FLAG_X0 = 0;

	        %   disp('    '),
  		%   disp('-----------------------------------------'); 
  		%   disp(' The algorithm attained max iteration.'),
                %   disp([' ITER = ',num2str(ITER)]),
  		%   disp(' The solution attained in max iteration.'),
 		%   X
  		%   disp('-----------------------------------------');
  		%   disp('    '),

                else
                   ITER = ITER + 1;
                end;