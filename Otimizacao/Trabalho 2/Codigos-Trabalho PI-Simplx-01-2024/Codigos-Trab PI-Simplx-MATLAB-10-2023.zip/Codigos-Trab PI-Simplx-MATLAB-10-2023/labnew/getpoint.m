%
% Obten��o do Ponto Inicial na demonstra��o 
% do m�todo de Pontos Interiores.
%


set(htxtResultX1,'Visible','off');
set(htxtResultX2,'Visible','off');

delete(get(hMainWin,'CurrentAxes'));

plot(v(:,1),v(:,2),'y-.');hold on;

set(get(hMainWin,'CurrentAxes'),'visible','off');
plot(v(:,1),v(:,2),'y-.');
axis([min(v(:,1))-1 max(v(:,1))+1 min(v(:,2))-1 max(v(:,2))+1 ]);

plot(min(v(:,1)),max(v(:,2)),'.'); 
hline = quiver(min(v(:,1)),max(v(:,2)),direcao(1),direcao(2),0);

% ------------------------------------------------------------
% Specified value considered zero.
% EPSLON0 = 1.0e-08;
% Specified tolerance such that a calculated DELTAX = X - XOLD
% is considered zero if abs(max(DELTAX)) < EPSLON1 .
% EPSLON1 = 5.0e-04;
  EPSLON1 = 1.0e-03;
% ------------------------------------------------------------
% Specified value considered zero.
  EPSLON0 = EPSLON1^5;
% ------------------------------------------------------------

% ------------------------------------
% Specified value considered infinite.
  INFMAX = 1.0e06;
% ------------------------------------

% ----------------------------------------------------------
% Define KALPHA
% KALPHA = input('fator KALPHA :  0 < KALPHA < 1 = ');
  KALPHA = 0.5;
% ----------------------------------------------------------

% ----------------------------------------------------------
% Define the number of iterations
% MAXITER = input('M�ximo n�mero de itera��es permitido = ');
  MAXITER = 100;
% ----------------------------------------------------------

% -----------------------------------------
% First call to the problem.
% Construction of the optimization problem.
%  [N,M,C,A,B,XMIN,XMAX,X0 ] = fhillie;
% load dados;
% -----------------------------------------

% ---------
  ITER =1;
  FLAG1=0; 
% ---------
 
htxtTemp = uicontrol('Style','Text',...
	                  'Units','normal',...
	                  'Position',[0.5 0.7 0.24 0.07],...
	                  'BackgroundColor',[1 1 0],...
		               'ForegroundColor',[0 0 0],...
		               'String','Selecione o primeiro Ponto Interior');

hplotContorno = plot(v(:,1),v(:,2),'b','LineWidth',5,'visible','off');

[x,y] = ginput(1);

 X0 = [x;y];

% X0 = (norm(B)/norm(A*C))*C;
plot(X0(1),X0(2),'wo');

FLAG_X0 = 1;

% Stockage the initial trial solution.
  X = X0;
  EVOLX = [X0];

% Evaluate objectif function.
  FOBJ = C'*X0;
  EVOLFOBJ = [FOBJ];

set(hplotContorno,'visible','on');

delete(htxtTemp);
clear htxtTemp x y ;