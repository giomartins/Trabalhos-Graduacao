  function [xint,A1,b1,g] = findintp(A,b,REL)
% xint = findintp(A,b,REL)
%
% Encontra um ponto interior proximo ao centro do poligono de restricoes
% descrito pelo seguinte conjunto de equacoes:
%
% Ax REL b,
%
% onde REL pode ser ">=" ou "<=".  
%
% xint -> Ponto interior ao poligono de restricoes
% A    -> matriz de restricoes lineares (m x n).
% b    -> vetor de restricoes (m x 1)
% REL  -> vetor de que indica as relacoes usadas
%	  em cada restricao:  1 equiv. a  ">=" e -1 equiv. a  "<="
%
% A1   -> Matriz transformada.
% b1   -> Vetor transformado.
% zint -> Ponto interior no sistema transformado.
%
% Ex: 
%	x  +  y +  z  <= 2
%  2x  - 3y       >= 3
%	x  -  y + 2z  <= 0
%
%       A = [ 1   1  1;	   b = [2;3;0];	   REL = [-1;1;-1];
%	           2  -3  0;
%	           1  -1  2;];
%

   epsilon = 1.0e-8;  % Valor abaixo do qual consideraremos como "zero".

 %%%%%%%%%%
 % Passo 1%
 %%%%%%%%%%
 % Transformar o problema original para a forma
 % A1x <= b1
 % x >= 0.
   xint = [];
   [m,n] = size(A);
   if (m <= n),
      disp('Erro: O numero de linhas da matriz de restricoes A');
      disp('deve ser maior do que o numero de colunas.');
      return;
   end;

 % Garante que as restricoes a serem utilizadas no
 % novo sistema de coordenadas sao do tipo ">=".
   restr = find(REL(m-n+1:m) < 0);
   if (~isempty(restr)),
      restr = restr + m - n;
      A(restr,:) = -A(restr,:);
      b(restr) = -b(restr);
      REL(restr) = -REL(restr);
   end;

 % Garante que as outras restricoes serao do tipo "<=".
   restr = find(REL(1:m-n) > 0);
   if (~isempty(restr)),
      A(restr,:) = -A(restr,:);
      b(restr) = -b(restr);
      REL(restr) = -REL(restr);
   end;
      
 % Submatriz utilizada na rotacao do sistema. 
   F = A(m-n+1:m,:);
   H = inv(F);

 % Rotacao para colocar os eixos paralelos as
 % restricoes : y = Fx -> Ax = A(F^-1)y = A1y <= b.
   A1 = A*H;

 % Translacao: y = z + d ->	A1z <= b - A1d. -> A1z <= b1.
   d =  b(m-n+1:m);
   b1 = b - A1*d;

 % Forca que os ultimos valores do vetor b1 sejam zero, previnindo
 % a ocorrencia de erros numericos
   b1(m-n+1:m) = zeros(n,1);

 % Normalizacao de b1 (diminuicao de erros numericos): b2 = kb1.
 % Isto � equivalente a aplicar a seguinte transformacao: z = kw,
 % onde k = max(b1)*I -> A1z <= b1 -> A1w <= b1/max(b1).
   k = max(b1);
   b2 = b1/k;

 %%%%%%%%%%
 % Passo 2%
 %%%%%%%%%%

 % Encontra a direcao de busca por inteceptacao.
 % g = zeros(n,1);
 % for i = m-n+1:m,
 %     g = g + (A(i,:)')/norm(A(i,:),2);
 % end;
 % g = F*g;
 % if (norm(g,2) < epsilon),
 %    g = ones(n,1);
 % end;
   g = ones(n,1);

 % Calcular as interceptacoes.
   restr = find(abs(A1(1:m-n,:)*g) > epsilon);
   intercept = b2(restr)./(A1(restr,:)*g);

 % Somente pontos criticos que respeitem
 % as restricoes z1 > 0, z2 >0 ... zn > 0.
   intercept = intercept(find(intercept > 0));

 % Ordena os pontos obtidos
   intercept = sort(intercept);

 % Adiciona o ponto (0;0) se ele for um ponto cr�tico.
   adiciona = find(REL(1:m-n).*b2(1:m-n) >= 0);
   if (isempty(adiciona)),
      intercept = [0;intercept];
   end;

 % Elimina redundancia.
   diff = abs(intercept(1:length(intercept)-1) - intercept(2:length(intercept)));
   intercept = [intercept(find(diff > epsilon));intercept(length(intercept))];

 % Encontra os pontos que sao criticos.
   j = 1;
   theend = 0;

   while ((theend == 0) & (j < length(intercept))),
 
         p1 = intercept(j)*g;
         p2 = intercept(j+1)*g;

         t1 = A1*p1 - b2;
         t2 = A1*p2 - b2;

         nulo = find(abs(t1) < epsilon);
         t1(nulo) = zeros(length(nulo),1);
  
         nulo = find(abs(t2) < epsilon);
         t2(nulo) = zeros(length(nulo),1);

         t1 = find(t1.*REL < 0);
         t2 = find(t2.*REL < 0); 

         if ((isempty(t1)) & (isempty(t2))),       
            theend = 1;
         else
            j = j+1;
         end;

   end;

   if (theend == 0),
      disp('Erro: Falha no algoritmo.');
      disp('Possiveis causas:');
      disp('    a) Algoritmo incorreto.');
      disp('    b) Problema mal formulado.');
      disp('    b) Restricoes L.D. no processo de rotacao.');
      return;
   end;

 %%%%%%%%%%
 % Passo 3%
 %%%%%%%%%%
  % Aplica as transformacoes inversas correspondentes
  % aquelas do passo 1 sobre os pontos encontrados.

  % Desnormalizacao: z = Kw.
    z1 = k*p1;
    z2 = k*p2;

  % Translacao: z = y - d.
    y1 = z1 + d;
    y2 = z2 + d;

  % Rotacao: y = Fx.
    x1 = H*y1;
    x2 = H*y2;

 % Calcula o ponto medio entre os dois
 % pontos encontrados no passo anterior.
   xint = (x1+x2)/2;

% Fim do algoritmo.

