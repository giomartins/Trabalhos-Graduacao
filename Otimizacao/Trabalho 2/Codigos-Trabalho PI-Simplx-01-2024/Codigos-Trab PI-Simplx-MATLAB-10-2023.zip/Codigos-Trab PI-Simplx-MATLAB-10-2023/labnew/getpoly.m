  function [A,b,REL,p] = getpoly(n,center,rmax),
%
% [A,b,REL,v] = getpoly(n)
%
% Desenha um poligono de 2 dimensoes 
% com "n" restricoes.
%
% [A,b,REL,v] = getpoly(n,center)
%
% Desenha um poligono com "n" restricoes
% com centro aprox. igual a "center".
%
% [A,b,REL,v] = getpoly(n,center,rmax)
%
% Desenha um poligono com "n" restricoes
% com centro aprox. igual a "center" e
% raio maximo igual a "rmax".
%
% A -> Matriz de restricoes.
% b -> Vetor do sistema: Ax <= b.
% REL -> Relacoes de desigualdade: -1 = "<=" e 1 = ">=".
% v -> Vertices do poligono.

  epsilon = 1.0e-9;
  var = 0.2;

  if (n < 3),
     disp('Imposs�vel!!');
      return;
  end;

if (nargin < 3),
  rmax = 4.0*(rand(1,1) + 1);
end;

if (nargin < 2)
  center = 2.0*rand(2,1)-1;
end;

dteta = (360/n); 

p = [];
r = [];

for j=1:n,
    teta = (j-1)*dteta*pi/180;
    d = rmax;
    p = [p;(center + d*[cos(teta);sin(teta)])'];
end;

p = [p;p(1,:)];

% Obtencao da matriz de restricoes e do vetor b.

A = [];
b = [];
REL = [];

% Valor considerado nulo.
epsilon = 1.0e-6;

for j=1:n,

  teta = (j-1)*dteta;
 
  dx = p(j+1,1) - p(j,1);
  dy = p(j+1,2) - p(j,2);

  if (abs(dx) > epsilon),

    m = dy/dx;
    c = -m*p(j,1) + p(j,2);

    A = [A;[-m 1]];
    b = [b;c];

  else

    c = p(j,1);

    A = [A;[1 0]];
    b = [b;c];

  end;

  % Determinacao das desigualdades.

  pmedio = (p(j,:)' + p(j+1,:)')/2;
  pmedio = (pmedio + center)/2;

  if (A(j,:)*pmedio > c),
     REL = [REL;1];
  else
     REL = [REL;-1];
  end;

end;

%figure;


V = version;
V = str2num(V(1));
if (V < 5),
   graf_attr = 'w';
else
   graf_attr = 'b';
end;

% plot(p(:,1),p(:,2),graf_attr);
% hold on;
% plot(p(:,1),p(:,2),[graf_attr,'o']);
% xlabel('X');
% ylabel('Y');
% title('Poligono de Restricoes');
% hold off;