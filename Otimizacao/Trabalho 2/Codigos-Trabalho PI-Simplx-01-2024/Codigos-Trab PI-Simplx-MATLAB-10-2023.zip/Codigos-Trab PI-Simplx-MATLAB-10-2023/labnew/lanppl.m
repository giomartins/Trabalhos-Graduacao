% --------------------------
% Deleta todas as vari�veis.
  clear;
  close all;
% --------------------------

% ---------------------------------------- 
% ---------------------------------------- 
  n = input(' Dimens�o do espa�o   =   ');

% Livro do Polyak Pagina 400.
% V. Klee and G. L. Minty, 
% How good is the simplex algorithm?, O. Shisha (ed.), Inequalities III, Academic 
% Press, New York, 1972,  159-175.
  [A,B,C,REL,xmin,xmax] = funcex01(n);


% --------------------------------- 
% Implementa��o do algoritmo Simplex
%               Max C^T.X
% sujeito a:    A.X <= B
% A fun��o retorna os valores ideais para X (vetor)
  [X] = algsplx(A,B,C)
  
  
% -------------------------------
% Algoritmo de pontos interiores.
  [ITER,EVOLX,EVOLFOBJ,X,FOBJ] = algpint(N,M,A,B,C,REL,X0,XMIN,XMAX)
% --------------------------------- 

  
% Transformar o problema V. Klee and G. L. Minty para a forma PPL.
% Colocar  um problema de programa��o linear qualquer
% na sua forma padr�o
% obj =1; % Pb. maximizar.
% vari = ones(1,size(A,2));
% [A,B,C]= formpad(A,b',c',obj,REL,vari);
% lambda = 0.99;
% [h,x0,x,y,vk,erro] = pontoint_m(A,C,B,lambda);
