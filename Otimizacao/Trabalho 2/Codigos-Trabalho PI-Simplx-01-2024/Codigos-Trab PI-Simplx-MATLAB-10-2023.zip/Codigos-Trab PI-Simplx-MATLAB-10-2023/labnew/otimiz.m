%
% Demostra��o do m�todo de Pontos Interiores
%
% Fun��o "Callback" para o bot�o "Proceed"
%

if (FLAG_X0 == 0)
  getpoint;
end;

while ITER <= MAXITER & FLAG1 == 0
  loopintp;      
end;

strResult = ['x1 = ',mat2str(fix(X(1)*1000)/1000)];
set(htxtResultX1,'String',strResult,'Visible','on');
strResult = ['x2 = ',mat2str(fix(X(2)*1000)/1000)];
set(htxtResultX2,'String',strResult,'Visible','on');

clear strResult;
