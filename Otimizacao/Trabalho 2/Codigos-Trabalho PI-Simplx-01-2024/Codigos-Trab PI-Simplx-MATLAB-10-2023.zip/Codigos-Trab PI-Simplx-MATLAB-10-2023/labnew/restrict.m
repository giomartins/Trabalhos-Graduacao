% Conjunto de instrucoes para tratamento da mudanca do n�mero de
% restricoes

if RESTRICOES ~= OLD_RESTR
   [A,B,REL,v] = getpoly(RESTRICOES,[10;10],7);
   % The number of variables.
   % M: The number of constraints.
   [M colunas] = size(A);

   % Ajuste das matrizes A e B
   for aux = 1:M
      A(aux,:) = -REL(aux)*A(aux,:);
      B(aux) = -REL(aux)*B(aux);
   end
   clear aux;

   REL(1:end) = -1;

   X0 = findintp(A,B,REL);
   %save dados;
   
   hold off;
   plot(v(:,1),v(:,2),'b','LineWidth',5);
   %plot(v(:,1),v(:,2),'b');
   axis([min(v(:,1))-1 max(v(:,1))+1 min(v(:,2))-1 max(v(:,2))+1 ]);
   hold on;
   %plot(v(:,1),v(:,2),['b','o']);
   
   plot(min(v(:,1)),max(v(:,2)),'.'); 
	hline = quiver(min(v(:,1)),max(v(:,2)),direcao(1),direcao(2),0);
   
   set(get(hMainWin,'CurrentAxes'),'visible','off');

   plot(v(:,1),v(:,2),'b','LineWidth',5);

   %   text(2,10,['M�X \{ F(x) = ',num2str(C(1)),'x_1 + ',num2str(C(2)),'x_2 \}'],'FontWeight','demi');

   set(hMainWin,'Visible','on');
   OLD_RESTR = RESTRICOES;
end

   




