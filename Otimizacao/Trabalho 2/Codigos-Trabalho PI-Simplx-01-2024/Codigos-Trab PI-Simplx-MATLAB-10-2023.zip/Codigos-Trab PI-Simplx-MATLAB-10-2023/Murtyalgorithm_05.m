% ==============================================================
% ==============================================================
  function [x, B] = Murtyalgorithm_05(A,c,x)
% MURTYALGORITHM Projection of interior point onto vertex.
%   Prototypes:
%      [x,B] = Murtyalgorithm(A,c,x)
%   Input arguments:
%      A: linear equality constraint matrix
%      c: linear objective function coefficients
%      x: a starting feasible point
%   Output arguments:
%      x: a vertex of {z | A*z = b, z >= 0}
%      B: set of basic variables
%   Example 1:  book's example
%      A = [1 0 0 1 0 1 -1; 0 1 0 0 -1 2 -1; 0 0 1 -1 1 1 -2];
%      c = [-10 4 6 2 4 8 10];
%      x = [5/2; 6; 13/2; 1/2; 1; 0; 0];
%      [xopt, B] = Murtyalgorithm(A,c,x);
%   Example 2:  
%      n = 2; % number of variables
%      op = oplpball(n,10,1);
%      A = [op.A; eye(op.inputdimension); -eye(op.inputdimension)];
%      b = [op.b; op.xmax; -op.xmin];
%      Aeq = op.Aeq;
%      c = op.C;
%      op.startingpoint = .75*rand(n,1);
%      x = op.startingpoint;
%      [mo,no] = size(A);
% 
%      % free variables to positive variables
%      A = [A -A];
%      Aeq = [Aeq -Aeq];
%      c = [c -c];
%      x = [max(0,x); min(0,x)];
% 
%      % slack variables
%      x = [x; b-A*x];
%      A = [A eye(size(A,1))];
%      Aeq = [Aeq zeros(size(Aeq,1),size(A,1))];
%      c = [c zeros(1,size(A,1))];
%      % equality constraints
%      A = [A; Aeq];
%      xopt = Murtyalgorithm(A,c,x);
%      % map to original variables
%      M = [eye(no) -eye(no) zeros(no,mo)];
%      xopt = M*xopt
%      xopt2 = M*xopt2
% -----------------------------------------------
% Updates:
% 2015/07/30 Amanda Dusse: initial version
% 2016/09/24 Igor Baratta:  Alteracao das condicoes de entrada no while,
% e opera????o dos pivots
% References:
% [1] Katta G. Murty. "Linear complementarity, linear and non linear 
%  programming", pag 474-477, 1997.
% Murty algorithm
  if nnz(A)/numel(A) > 1e-4, A = full(A); end
  [m,n] = size(A); % number of inequality constraints and variables
  B = find(x' > 0); if numel(B) == m && rank(A(:,B)) == m, return, end % trivial case
  B = 1:n; % index set of basic variables
  [R,jb] = rref(A,0); % reduced row echelon form
  m = numel(jb); % basis cardinality
  while numel(B) > m
      % search direction
        a = 1:size(R,2); a(jb) = []; % columns that are not part of eye matrix
        [~,ia] = max(x(B(a))); % allow more displacement
        d = zeros(n,1); d(B(jb)) = -R(1:m,a(ia)); d(B(a(ia))) = 1;
      
      % step length
        z = c*d;
        rate = x(B)./d(B);
        i = [];
        if z <= 0
            i = find(d(B) < 0 & rate <= 0);
            [lambda,ii] = min(-rate(i));
        end
        if isempty(i) && z >= 0
            i = find(d(B) > 0 & rate >= 0);
            [lambda,ii] = max(-rate(i));
        end
        i = i(ii); % variable leaving basis
      
      % stop criterion: unbounded optimal solution
        if isempty(i), B = []; break, end
      
      % step towards search direction
        x = max(0, x + lambda*d); x(B(i)) = 0;
      
      % update basis
        B(i) = [];
      
      % update reduced form
        if any(jb == i)
         % pivot operation
           ib = find(R(:,i)); % row index
           [rmax,in] = max(abs(R(ib,a))); in = a(in); % column index
           if rmax > 1e-12
               R(ib,:) = R(ib,:)/R(ib,in); % normalization
               inp = 1:m; inp(ib) = [];
               R(inp,:) = R(inp,:) - R(inp,in)*R(ib,:); % reduction
               jb(jb == i) = in; % update index of eye matrix
           else
               R(ib,:) = 0; R([ib m],:) = R([m ib],:); % zero row comes last
               jb(jb == i) = []; m = m - 1; % reduce basis cardinality
           end
        end
        R(:,i) = []; jb(jb>i) = jb(jb>i)-1; % remove column
  end
  end 
% ==============================================================
% ============================================================== 
  function r = rank(A,tol)
  if issparse(A), s = svds(A); else s = svd(A); end
  if nargin < 2, tol = max(size(A))*eps(max(s)); end
  r = sum(s > tol);
  end
% ==============================================================
% ==============================================================
